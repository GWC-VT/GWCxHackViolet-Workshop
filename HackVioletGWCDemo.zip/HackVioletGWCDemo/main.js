// // EXAMPLE: having the navbar slowly fade in

// // Starts out by hiding the 'nav' element by setting its opacity to 0
// document.getElementById('nav').style.opacity = '0';

// //setTimeout function is intended to apply an initial delay (100ms)
// setTimeout(() => {
//     // Adds a smooth transition effect for the 'opacity' property over 1 second
//     document.getElementById('nav').style.transition = 'opacity 1s';

//     // Sets the opacity to 1, making the 'nav' element visible
//     document.getElementById('nav').style.opacity = '1';
// }, 100);

// EXAMPLE: navbar slides down 

// // Moves the 'nav' element above the screen by translating it vertically by -100%
// document.getElementById('nav').style.transform = 'translateY(-100%)';

// setTimeout(() => {
//     document.getElementById('nav').style.transition = 'transform 0.5s';
    
//     // Translates the 'nav' element vertically to 0, bringing it down into view
//     document.getElementById('nav').style.transform = 'translateY(0)';
// }, 100);





// EXAMPLE: cursor highlighting each link on the navbar

// variable that collects all of the 'a' elements within the 'nav' element on the document
const navLinks = document.querySelectorAll('nav a');

//uses the forEach method
// Iterates over each 'a' element in the variable we just created
navLinks.forEach(link => {

    //Event listener: a function that waits for something to happen so they can respond to it
    // Adds an event listener for 'mouseenter' (hovering over) on each 'a' element
    link.addEventListener('mouseenter', () => {
        link.style.fontSize = '1.1rem';
    });

    // Adds an event listener for 'mouseleave' (moving the mouse away) on each 'a' element
    link.addEventListener('mouseleave', () => {
        // Resets the font size to its original value when the mouse leaves the element
        link.style.fontSize = '';
    });
});